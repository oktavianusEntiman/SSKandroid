package com.si_ware.neospectra.History.View;

/**
 * Created by amrwinter on 1/20/18.
 */

public class HistoryView {
    void showHistory() {

    }
}
