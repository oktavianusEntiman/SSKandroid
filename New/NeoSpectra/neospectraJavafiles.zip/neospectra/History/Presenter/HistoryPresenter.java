package com.si_ware.neospectra.History.Presenter;

/**
 * Created by amrwinter on 1/20/18.
 */

public class HistoryPresenter {

    void clearAllHistory(){

    }
}
