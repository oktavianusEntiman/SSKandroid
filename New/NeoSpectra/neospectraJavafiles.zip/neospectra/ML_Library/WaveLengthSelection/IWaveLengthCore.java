package com.si_ware.neospectra.ML_Library.WaveLengthSelection;

/**
 * Created by AmrWinter on 1/9/18.
 */

public interface IWaveLengthCore {
    int GAPLSSP();
    int SFS();
}
