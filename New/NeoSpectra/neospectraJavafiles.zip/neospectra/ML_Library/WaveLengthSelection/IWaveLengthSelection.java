package com.si_ware.neospectra.ML_Library.WaveLengthSelection;

import java.util.ArrayList;

/**
 * Created by AmrWinter on 1/8/18.
 */

public interface IWaveLengthSelection {

    int do_Selection();
}
