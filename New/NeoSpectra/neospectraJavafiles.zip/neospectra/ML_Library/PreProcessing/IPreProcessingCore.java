package com.si_ware.neospectra.ML_Library.PreProcessing;

/**
 * Created by AmrWinter on 1/8/18.
 */

public interface IPreProcessingCore {
    int osc_1();
    int osc_2();
    int emsc();
    int oplec();
}
