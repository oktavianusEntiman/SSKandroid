package com.si_ware.neospectra.ML_Library.FeatureExtraction;

/**
 * Created by AmrWinter on 1/8/18.
 */

public interface IFeatureExtraction {
    int do_FeatureExtraction();
}
